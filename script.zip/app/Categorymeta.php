<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Categorymeta extends Model
{
	
	
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ordermeta extends Model
{
     public $timestamps = false;
}

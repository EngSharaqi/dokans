<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Useroption extends Model
{
    //
}
